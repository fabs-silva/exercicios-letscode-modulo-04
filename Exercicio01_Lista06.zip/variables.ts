export const colors = {
  bgColor: '#e9c3b1',
  lightColor: '#f5f9fa',
  darkColor: '#311d23',
  accentColor: '#ab523c',
  baseColor: '#8d7066',
};
